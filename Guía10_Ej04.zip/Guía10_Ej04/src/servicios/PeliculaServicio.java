package servicios;

import entidades.Pelicula;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class PeliculaServicio {
    
    private final List<Pelicula> listaPeliculas;

    public PeliculaServicio() {
        listaPeliculas = new ArrayList<>();
    }

    public void crearPelicula() {
        Scanner scanner = new Scanner(System.in).useDelimiter("\n");

        System.out.println("Ingrese el título de la película:");
        String titulo = scanner.nextLine();

        System.out.println("Ingrese el director de la película:");
        String director = scanner.nextLine();

        System.out.println("Ingrese la duración de la película (en horas):");
        double duracion = scanner.nextDouble();
        scanner.nextLine();

        Pelicula pelicula = new Pelicula(titulo, director, duracion);
        listaPeliculas.add(pelicula);

        System.out.println("Pelicula creada con éxito.");
    }

    public void mostrarPeliculas() {
        System.out.println("Lista de películas:");
        listaPeliculas.forEach((pelicula) -> {
            System.out.println(pelicula);
        });
    }

    public void mostrarPeliculasMayorAUnaHora() {
        System.out.println("Películas con duración mayor a 1 hora:");
        listaPeliculas.stream().filter((pelicula) -> (pelicula.getDuracion() > 1)).forEachOrdered((pelicula) -> {
            System.out.println(pelicula);
        });
    }

    public void ordenarPeliculasPorDuracionDescendente() {
    Collections.sort(listaPeliculas, (p1, p2) -> Double.compare(p2.getDuracion(), p1.getDuracion()));
    System.out.println("Películas ordenadas por duración (de mayor a menor):");
    listaPeliculas.forEach((pelicula) -> {
        System.out.println(pelicula);
    });
}

public void ordenarPeliculasPorDuracionAscendente() {
    Collections.sort(listaPeliculas, (p1, p2) -> Double.compare(p1.getDuracion(), p2.getDuracion()));
    System.out.println("Películas ordenadas por duración (de menor a mayor):");
    listaPeliculas.forEach((pelicula) -> {
        System.out.println(pelicula);
    });
}

    public void ordenarPeliculasPorTitulo() {
        Collections.sort(listaPeliculas, (p1, p2) -> p1.getTitulo().compareToIgnoreCase(p2.getTitulo()));
        System.out.println("Películas ordenadas por título:");
        listaPeliculas.forEach((pelicula) -> {
            System.out.println(pelicula);
        });
    }

    public void ordenarPeliculasPorDirector() {
        Collections.sort(listaPeliculas, (p1, p2) -> p1.getDirector().compareToIgnoreCase(p2.getDirector()));
        System.out.println("Películas ordenadas por director:");
        listaPeliculas.forEach((pelicula) -> {
            System.out.println(pelicula);
        });
    }
}
