package guía10_ej04;

import servicios.PeliculaServicio;
import java.util.Scanner;

public class Guía10_Ej04 {

    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    
    PeliculaServicio peliculaServicio = new PeliculaServicio();

    String opcion;
    do {
        clearScreen(); // Limpia la pantalla

        System.out.println("----- Menú -----");
        System.out.println("1. Crear película");
        System.out.println("2. Mostrar todas las películas");
        System.out.println("3. Mostrar películas con duración mayor a 1 hora");
        System.out.println("4. Ordenar películas por duración (de mayor a menor)");
        System.out.println("5. Ordenar películas por duración (de menor a mayor)");
        System.out.println("6. Ordenar películas por título");
        System.out.println("7. Ordenar películas por director");
        System.out.println("0. Salir");
        System.out.print("Ingrese la opción deseada: ");
        opcion = scanner.nextLine();

        switch (opcion) {
            case "1":
                peliculaServicio.crearPelicula();
                break;
            case "2":
                peliculaServicio.mostrarPeliculas();
                break;
            case "3":
                peliculaServicio.mostrarPeliculasMayorAUnaHora();
                break;
            case "4":
                peliculaServicio.ordenarPeliculasPorDuracionDescendente();
                break;
            case "5":
                peliculaServicio.ordenarPeliculasPorDuracionAscendente();
                break;
            case "6":
                peliculaServicio.ordenarPeliculasPorTitulo();
                break;
            case "7":
                peliculaServicio.ordenarPeliculasPorDirector();
                break;
            case "0":
                System.out.println("¡Hasta luego!");
                break;
            default:
                System.out.println("Opción inválida. Intente nuevamente.");
        }

        System.out.println(); // Separador visual entre cada opción del menú
        System.out.print("Presione Enter para continuar...");
        scanner.nextLine(); // Espera a que el usuario presione Enter para continuar

    } while (!opcion.equals("0"));
}

private static void clearScreen() {
    // Limpia la pantalla imprimiendo múltiples saltos de línea
    System.out.print("\033[H\033[2J");
    System.out.flush();
}
}
